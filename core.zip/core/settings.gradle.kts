rootProject.name = "core"
